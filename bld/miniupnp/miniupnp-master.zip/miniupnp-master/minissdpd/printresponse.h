/* $Id: $ */
/* Project : miniupnp
 * Author : Thomas BERNARD
 * copyright (c) 2016 Thomas Bernard
 * This software is subjet to the conditions detailed in the
 * provided LICENCE file. */
#ifndef PRINTRESPONSE_H_INCLUDED
#define PRINTRESPONSE_H_INCLUDED

void printresponse(const unsigned char * resp, int n);

#endif /* PRINTRESPONSE_H_INCLUDED */
