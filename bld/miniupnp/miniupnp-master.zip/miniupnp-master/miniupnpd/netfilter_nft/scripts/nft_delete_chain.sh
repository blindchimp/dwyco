#! /sbin/nft -f

delete chain nat miniupnpd
delete chain nat miniupnpd-pcp-peer
delete chain filter miniupnpd
